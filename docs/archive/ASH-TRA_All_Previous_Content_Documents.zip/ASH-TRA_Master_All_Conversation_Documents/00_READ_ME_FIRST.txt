ASH-TRA LANGUAGES BRAZIL
MASTER WEBSITE CONTENT PACKAGE

This folder contains every final editable Word document and working website prototype created from the beginning of this conversation.

CONTENTS

01 Home and Overall Website
- Complete homepage and full-site conversion strategy for ash-tra.com.

02 About
- Original complete About-page replacement copy.
- Expanded About-page rebuild. Both are included because both versions were created during the project.

03 Values and Mission
- One mission, ten values, complete page copy, visual direction, SEO and implementation guidance.

04 Student Application Process
- Full start-to-finish student journey: intake, interview, documents, fees, enrolment, immigration boundaries, arrival, airport welcome, classes, attendance and integration.

05 Prices and Quotation
- Tuition and investment page, 12-to-50-week pricing structure, documentation fee, optional support conditions and quotation specifications.

06 Brazil Destination Page
- Picture-first inspirational Brazil page covering culture, history, geography, regional learning, online options and educational cultural activities.

07 Contact and EdBot
- Complete Contact-page replacement, form fields, Ashlyn A Merrigan Cursos contact details, WhatsApp copy, and EdBot conversation flows.

08 Working Prototypes
- Dynamic tuition quotation calculator in HTML.
- Contact form and EdBot interface prototype in HTML.

09 Project Notes
- Master file manifest.
- Summary of the main programme and website decisions made during the conversation.

IMPORTANT SETUP NOTES
- contact@ash-tra.com was suggested as a website mailbox but must be created and tested before publication.
- School wording must never promise visa or residence approval.
- The school provides educational and administrative documents, not immigration legal advice or representation.
- Legal, consumer, refund, attendance and data-protection wording should be reviewed before publication.
- All cultural activities, practical support, airport welcome and related costs depend on location, dates, weather, availability and the final written agreement.
